Command line used to find this crash:

/home/ubuntu/loopfuzz/afl-fuzz -d -i /home/ubuntu/experiments/in-ftp -x /home/ubuntu/experiments/ftp.dict -o out-lightftp-loopfuzz -N tcp://127.0.0.1/2200 -P FTP -D 10000 -q 3 -s 3 -E -K -m none -t 5000+ -c /home/ubuntu/experiments/ftpclean ./fftp fftp.conf 2200

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 0 B.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
me a mail at <lcamtuf@coredump.cx> once the issues are fixed - I'd love to
add your finds to the gallery at:

  http://lcamtuf.coredump.cx/afl/

Thanks :-)

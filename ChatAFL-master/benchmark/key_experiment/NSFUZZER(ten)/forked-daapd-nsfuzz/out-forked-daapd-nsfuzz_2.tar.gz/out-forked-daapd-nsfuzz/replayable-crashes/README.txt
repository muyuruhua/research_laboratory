Command line used to find this crash:

/home/ubuntu/nsfuzz/afl-fuzz -d -i /home/ubuntu/experiments/in-daap -o out-forked-daapd-nsfuzz -N tcp://127.0.0.1/3689 -P HTTP -m none -t 2000+ -q 3 -s 3 -E -K -R /home/ubuntu/experiments/forked-daapd-nsfuzz/src/forked-daapd -d 0 -c /home/ubuntu/experiments/forked-daapd.conf -f

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 0 B.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
me a mail at <lcamtuf@coredump.cx> once the issues are fixed - I'd love to
add your finds to the gallery at:

  http://lcamtuf.coredump.cx/afl/

Thanks :-)
